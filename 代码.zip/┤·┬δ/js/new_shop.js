/* 
* @Author: anchen
* @Date:   2018-02-14 15:24:54
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-14 15:39:13
*/

$(document).ready(function(){
    // 点击清空联系人
    $('#deletepeople').click(function(){
        $('#contacts').val('');
        $('#phone').val('');
    })
    //添加联系人按钮跳转？
    $('#add_contacts').click(function(){
        //这里写跳转到添加联系人界面
        //
        //
        //
        //
        //
    })
    //表单提交
    //记录表单内容
    function record_form_info(){
        var shop_address = $('#shop_address').val();//地址
        var shop_name = $('#shop_name').val();//名称
        var contacts = $('#contacts').val();//联系人名字
        var phone = $('#phone').val();//联系人电话
        var shop_type = $('#shop_type option:selected').val();//商铺类型选中值，有可能没选中，需要判断？
    };
    //添加水电表按钮跳转？
    $('#add_forminfo').click(function(){
        record_form_info();
        //这里写跳转到添加水电表界面
        //
        //
        //
        //
    })
    //保存修改
    $('#save_change').click(function(){
        record_form_info();
        //
        //
        //
    })
});
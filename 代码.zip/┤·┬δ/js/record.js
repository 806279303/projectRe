/* 
* @Author: anchen
* @Date:   2018-02-18 16:54:47
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-18 23:57:16
*/

$(document).ready(function(){
    //左边季度列表点击相应改变
    $('#quarter li').click(function(){
        $(this).addClass('active').siblings().removeClass('active')
    })
    //点击生成本子
    $('#create_book').click(function(){
        $('#screen').fadeIn();
    })
    $('#close_create').click(function(){
        $('#screen').fadeOut();
    })
    //点击水表电表该表相应表格
    $('#ele_char_button').click(function(){
        //按钮样式
       $('#ele_char_button').removeClass('difbc');
       $('#ele_char_button').addClass('samebc');
       $('#water_char_button').removeClass('samebc');
       $('#water_char_button').addClass('difbc');
       //表格相应隐藏显示
       $('#water_char').hide();
       $('#ele_char').show();
    })
    $('#water_char_button').click(function(){
       $('#water_char_button').removeClass('difbc');
       $('#water_char_button').addClass('samebc');
       $('#ele_char_button').removeClass('samebc');
       $('#ele_char_button').addClass('difbc');
       //表格相应隐藏显示
       $('#ele_char').hide();
       $('#water_char').show();
    })


});
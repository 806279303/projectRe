
$(document).ready(function(){
    // 点击清空联系人
    $('#deletepeople').click(function(){
        $('#contacts').val('');
        $('#phone').val('');
    })
    //点击表单叉叉弹窗提示是否删除商铺
    $('#deleteform').click(function(){
        $('#screen').fadeIn();
    })
    var shop_name = $('#shop_name').text();//获取到商铺的名称
    //点击提示框的确认按钮事件
    $('#tip_submit').click(function(){
        //alert('删除数据')
        //这里先删除数据，再弹出删除成功的提示框,然后再跳转?
        //
        //
        //
        //成功提示框
        $('#isDel').hide();
        $('#sucDel').show();
        setTimeout(function(){
            $('#screen').fadeOut();
            //弹窗消失，跳转
            //跳转
            //
            //
            //
        },1000)
        
    })
    //点击提示框的取消按钮事件
    $('#tip_reset').click(function(){
        $('#screen').hide();
    })
});
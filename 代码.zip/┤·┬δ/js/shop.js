/* 
* @Author: anchen
* @Date:   2018-02-14 17:28:59
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-15 12:39:48
*/
var obj = [{
    "shop_name":"博雅园",
    "shop_address":"博雅园",
    "ele_water_char":"水电表",
    "contacts":"江师傅、曾经理",
    "shop_type":"实体",
    "ele_water_record":"水电费记录",
},{
    "shop_name":"博雅园",
    "shop_address":"博雅园",
    "ele_water_char":"水电表",
    "contacts":"江师傅、曾经理",
    "shop_type":"实体",
    "ele_water_record":"水电费记录",
}]
$(document).ready(function(){
    function loadChar(){//后台操作的时候把函数头直接引用就行
        //界面加载的时候导入数据
        $.ajax({
            url: '',//地址
            type: 'post',
            dataType: 'json',
            success:function(Json){
                alert(Json);
                var obj = eval(Json);//记录后台传进的对象
                var html = '';//新建html代码
                //生成表格
                for(var i=0;i<a.length;i++){
                    //新建一行，一行7列
                    html += '<tr>';
                    html +=     '<td>' + obj[i].shop_name + '</td>';
                    html +=     '<td>' + obj[i].shop_address + '</td>';
                    html +=     '<td>' + obj[i].ele_water_char + '</td>';
                    html +=     '<td>' + obj[i].contacts + '</td>';
                    html +=     '<td>' + obj[i].shop_type + '</td>';
                    html +=     '<td>' + obj[i].ele_water_record + '</td>';
                    html +=     '<td><img src="img/shop/shop-icon-change.png" alt="" /></td>';
                    html += '</tr>'; 
                }
                //样式需要 多两行空白表格
                for(var j=0;j<2;j++){
                    html += '<tr>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html +=     '<td></td>';
                    html += '</tr>'; 
                }
                //插入表格
                $('#tb table').append(html);
            },error:function(){
                alert('加载失败')
            }
        })
    }
    //为每行数据记录一个索引值，方便点击修改时候找到此条数据
    $('#tb table').find('tr').each(function(index){
        $(this).data('index', index-1);
    })
    //点击修改按钮的时候
    $('#tb table tr td').find('a').click(function(){
        var shop_index = $(this).parent().parent().data('index');//这一行数据的索引，第一行文采园 0 
        var shop_name = $(this).parent().parent().find('td').eq(1).text();//点击修改的商铺名称
        location.href='';//点击修改商铺的时候要跳转的后台，需要ajax吗？
        return false;//阻止a标签默认跳转
    })
    
    
    
});
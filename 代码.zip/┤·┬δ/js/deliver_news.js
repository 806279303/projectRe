/* 
* @Author: anchen
* @Date:   2018-02-19 00:51:36
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-19 01:58:21
*/

$(document).ready(function(){
    //选中时候打勾的形状改变
    $('#tb table tr td label').each(function(){
        $(this).click(function(){
            if($(this).prev().is(':checked')){
                $(this).removeClass('bc')
            }else{
                $(this).addClass('bc')
            }
        })
    })
    

    //全选
    $('#all_select').click(function(){
        $('#tb table tr td label').addClass('bc');
        $('#tb table tr td :checkbox').prop('checked',true);
    })
    //反选
    $('#con_select').click(function(){
        $('#tb table tr td label').each(function(){
            if($(this).hasClass('bc')){
                $(this).removeClass('bc')
            }else{$(this).addClass('bc')}
        })
        $('#tb table tr td :checkbox').each(function(){
            $(this).prop('checked',!$(this).prop('checked'))
        })
    })
});
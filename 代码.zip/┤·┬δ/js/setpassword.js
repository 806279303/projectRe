/* 
* @Author: anchen
* @Date:   2018-02-12 12:59:49
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-12 19:09:25
*/
$(document).ready(function() {
    //显示密码
    $('.sec').each(function(){
        $(this).mousedown(function(event) {
            $(this).prev().attr('type','text');
            })
        $(this).mouseup(function(event){
            $(this).prev().attr('type','password');
        })
    })
    //获取焦点的时候错误提示隐藏
    $('input[type=password]').focus(function(event) {
        $('#errortxt').css('visibility', 'hidden');
    });

    //修改水费单价提交表单
    $('#price_submit').click(function(){
        var water_price = $('#water_price').val();
        var ele_price = $('#ele_price').val();
        if(water_price!=''&&ele_price!=''){
           //先显示修改成功再跳转
                //弹窗
                $('#screen').fadeIn(500);
                setTimeout(function(){
                    $('#screen').fadeOut(500);
                },1500)
                //跳转
                //
                //
                //
                //
                //
                //
                // 
                return false;
        }else{
            return false;
        }
    })
    //修改密码表单验证
    $('#password_submit').click(function(){

        var old_password = $('#old_password').val();
        var new_password = $('#new_password').val();
        var sure_password = $('#sure_password').val();
        //判断管理员原密码是否正确
        //
        //
        //
        //
        //判断管理员两次新密码是否一样
        //不为空
        if(new_password!=''&&sure_password!=''){
            //不等
            if(new_password!=sure_password){
                $('#errortxt').html('*两次密码不一致');
                $('#errortxt').css('visibility', 'visible');
                return false;
            }
            //等于
            else{
                //长度小于6
                if(new_password.length<6){
                    $('#errortxt').html('*新密码长度小于6位！');
                    $('#errortxt').css('visibility', 'visible');
                    return false;
                }
                //等于6
                //先显示修改成功再跳转
                //弹窗
                $('#screen').fadeIn(500);
                setTimeout(function(){
                    $('#screen').fadeOut(500);
                },1500)//跳转
                //
                //
                //
                //
                //
                //
                //
                return false;
            }
        }
        //新密码确认密码可能一个为空
        else{
            $('#errortxt').html('*两次密码不一致');
            $('#errortxt').css('visibility', 'visible');
            return false;
        }
    })
    //修改成功返回主页
});
    